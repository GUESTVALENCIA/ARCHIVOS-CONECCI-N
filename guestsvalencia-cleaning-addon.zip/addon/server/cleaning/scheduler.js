// Cleaning scheduler that scans reservations and sends WhatsApp orders at the right times
const { readJSON, writeJSON } = require('./storage');
const pathReservations = 'data/reservations.json';
const pathCleaning = 'data/cleaning.json';
const pathSettings = 'data/cleaning-settings.json';

const fetch = (...args) => import('node-fetch').then(({default: fetch}) => fetch(...args));

function nowISO() { return new Date().toISOString(); }
function toISO(d) { return (d instanceof Date) ? d.toISOString() : new Date(d).toISOString(); }
function addMinutes(iso, mins) { return new Date(new Date(iso).getTime() + mins*60000).toISOString(); }
function addHours(iso, hrs) { return addMinutes(iso, hrs*60); }
function diffMs(a, b) { return new Date(a).getTime() - new Date(b).getTime(); }
function uid(prefix='tsk') { return `${prefix}_${Math.random().toString(36).slice(2,8)}_${Date.now().toString(36)}`; }

function defaultSettings() {
  return {
    enabled: true,
    pre_hours: 3,           // horas antes del check-in para pre-clean
    post_minutes: 60,       // minutos después del check-out para post-clean
    midstay_after_nights: 7,// si estancia >= 7 noches, programar mid-stay
    midstay_day: 4,         // día de limpieza a mitad de estancia
    assign: 'round_robin',  // 'round_robin' | 'susana' | 'paloma'
    last_assigned: 'paloma' // para RR
  };
}

async function sendWhatsApp(toNumberE164, text) {
  const WA_ACCESS_TOKEN = process.env.WA_ACCESS_TOKEN;
  const WA_PHONE_NUMBER_ID = process.env.WA_PHONE_NUMBER_ID;
  if (!WA_ACCESS_TOKEN || !WA_PHONE_NUMBER_ID) {
    console.log('[WA] (dry-run) ->', toNumberE164, text);
    return { ok:true, dry:true };
  }
  const url = `https://graph.facebook.com/v20.0/${WA_PHONE_NUMBER_ID}/messages`;
  const r = await fetch(url, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${WA_ACCESS_TOKEN}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      messaging_product: "whatsapp",
      to: toNumberE164.replace(/\D/g,''),
      type: "text",
      text: { body: text }
    })
  });
  if (!r.ok) {
    const t = await r.text();
    throw new Error(`WA send failed ${r.status} ${t}`);
  }
  return r.json();
}

function chooseAssignee(settings) {
  if (settings.assign === 'susana') return 'susana';
  if (settings.assign === 'paloma') return 'paloma';
  // round_robin
  const next = settings.last_assigned === 'susana' ? 'paloma' : 'susana';
  settings.last_assigned = next;
  writeJSON(pathSettings, settings);
  return next;
}

function ensureTask(tasks, keyFn) {
  const k = keyFn();
  return tasks.find(t => t.key === k);
}

function makeTask(res, type, whenISO, assignee) {
  return {
    id: uid('clean'),
    key: `${res.id}:${type}`,
    reservation_id: res.id,
    property_id: res.property_id,
    type, // 'pre_arrival' | 'mid_stay' | 'post_checkout' | 'manual'
    scheduled_at: whenISO,
    assigned_to: assignee, // 'susana' | 'paloma' | phone
    status: 'scheduled',   // 'scheduled' | 'sent' | 'ack' | 'done' | 'failed'
    created_at: nowISO(),
    logs: []
  };
}

function computeTasks(res, settings, tasks) {
  // returns array of new tasks to push
  const out = [];
  const checkIn = toISO(res.check_in);
  const checkOut = toISO(res.check_out);
  const nights = Math.max(1, Math.round((new Date(checkOut)-new Date(checkIn))/(1000*3600*24)));
  // pre-arrival
  const preAt = addHours(checkIn, -settings.pre_hours);
  if (!ensureTask(tasks, () => `${res.id}:pre_arrival`)) {
    out.push(makeTask(res, 'pre_arrival', preAt, chooseAssignee(settings)));
  }
  // post-checkout
  const postAt = addMinutes(checkOut, settings.post_minutes);
  if (!ensureTask(tasks, () => `${res.id}:post_checkout`)) {
    out.push(makeTask(res, 'post_checkout', postAt, chooseAssignee(settings)));
  }
  // mid-stay
  if (nights >= settings.midstay_after_nights) {
    const midAt = addHours(addMinutes(checkIn, (settings.midstay_day*24)*60), 0); // day N at same hour
    if (!ensureTask(tasks, () => `${res.id}:mid_stay`)) {
      out.push(makeTask(res, 'mid_stay', midAt, chooseAssignee(settings)));
    }
  }
  return out;
}

async function tick() {
  const settings = readJSON(pathSettings, defaultSettings());
  if (!settings.enabled) return;

  const reservations = readJSON(pathReservations, []);
  const tasks = readJSON(pathCleaning, []);

  // Generate tasks for all reservations
  let added = 0;
  for (const res of reservations) {
    if (!res || !res.id || !res.property_id || !res.check_in || !res.check_out) continue;
    const newOnes = computeTasks(res, settings, tasks);
    if (newOnes.length) {
      tasks.push(...newOnes);
      added += newOnes.length;
    }
  }
  if (added) writeJSON(pathCleaning, tasks);

  // Send pending tasks when time is due
  const now = new Date();
  for (const t of tasks) {
    if (t.status !== 'scheduled') continue;
    const due = new Date(t.scheduled_at);
    if (due <= now) {
      try {
        const target = (t.assigned_to === 'susana') ? process.env.CLEANING_SUSANA
                     : (t.assigned_to === 'paloma') ? process.env.CLEANING_PALOMA
                     : t.assigned_to;
        const msg = buildMessage(t);
        await sendWhatsApp(target, msg);
        t.status = 'sent';
        t.sent_at = nowISO();
        t.logs.push({ at: t.sent_at, action: 'send', ok: true });
      } catch (e) {
        console.error('[cleaning] send failed', e.message);
        t.status = 'failed';
        t.logs.push({ at: nowISO(), action: 'send', ok: false, error: e.message });
      }
    }
  }

  writeJSON(pathCleaning, tasks);
}

function buildMessage(t) {
  const label = t.type === 'pre_arrival' ? 'PRE-LLEGADA'
              : t.type === 'mid_stay' ? 'MEDIA ESTANCIA'
              : t.type === 'post_checkout' ? 'POST-SALIDA'
              : 'LIMPIEZA';
  return `🧹 ${label}
Alojamiento: ${t.property_id}
Reserva: ${t.reservation_id}
Hora programada: ${new Date(t.scheduled_at).toLocaleString()}

Responde *LISTO* al terminar o *INCIDENCIA: ...* para reportar.`;
}

let interval = null;
function init(app, options={}) {
  if (interval) clearInterval(interval);
  // run every 60s
  interval = setInterval(tick, 60*1000);
  // and run once after boot
  tick();
  console.log('[cleaning] scheduler active');
  // Expose helper for webhook ACKs (optional)
  app.locals.cleaningAck = (from, text) => {
    const tasks = readJSON(pathCleaning, []);
    const targetDigits = (from||'').replace(/\D/g,'');
    for (const t of tasks) {
      if (t.status === 'sent') {
        // naive: mark the latest sent as ack/done on LISTO
        if (/^listo\b/i.test(text)) {
          t.status = 'done'; t.done_at = nowISO();
          t.logs.push({ at: t.done_at, action:'ack', note:'LISTO' });
        } else if (/^incidencia:/i.test(text)) {
          t.status = 'ack'; t.ack_at = nowISO();
          t.logs.push({ at: t.ack_at, action:'incident', note:text });
        }
      }
    }
    writeJSON(pathCleaning, tasks);
  };
}

module.exports = { init, buildMessage };
