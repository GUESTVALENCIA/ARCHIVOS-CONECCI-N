const express = require('express');
const { readJSON, writeJSON } = require('./storage');
const pathReservations = 'data/reservations.json';
const pathCleaning = 'data/cleaning.json';
const pathSettings = 'data/cleaning-settings.json';

const fetch = (...args) => import('node-fetch').then(({default: fetch}) => fetch(...args));
const WA_ACCESS_TOKEN = process.env.WA_ACCESS_TOKEN;
const WA_PHONE_NUMBER_ID = process.env.WA_PHONE_NUMBER_ID;

function ensureAuth(req, res, next) {
  const key = req.get('x-admin-key');
  if (!process.env.ADMIN_KEY || key !== process.env.ADMIN_KEY) {
    return res.status(401).json({ ok:false, error:'unauthorized' });
  }
  next();
}

async function waSendText(to, bodyText) {
  if (!WA_ACCESS_TOKEN || !WA_PHONE_NUMBER_ID) {
    console.log('[WA] (dry-run) ->', to, bodyText);
    return { ok:true, dry:true };
  }
  const url = `https://graph.facebook.com/v20.0/${WA_PHONE_NUMBER_ID}/messages`;
  const r = await fetch(url, {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${WA_ACCESS_TOKEN}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ messaging_product:"whatsapp", to: to.replace(/\D/g,''), type:"text", text:{ body: bodyText } })
  });
  if (!r.ok) throw new Error(`WA send failed ${r.status} ${await r.text()}`);
  return r.json();
}

module.exports = function(app){
  const router = express.Router();

  // Cleaning settings
  router.get('/cleaning/settings', ensureAuth, (req,res)=>{
    const s = readJSON(pathSettings, null);
    res.json({ ok:true, settings: s });
  });
  router.put('/cleaning/settings', ensureAuth, express.json(), (req,res)=>{
    const s = req.body || {};
    writeJSON(pathSettings, s);
    res.json({ ok:true });
  });

  // Cleaning tasks
  router.get('/cleaning', ensureAuth, (req,res)=>{
    const tasks = readJSON(pathCleaning, []);
    res.json({ ok:true, tasks });
  });

  // Manual assign/send to cleaner
  router.post('/cleaning/assign', ensureAuth, express.json(), async (req,res)=>{
    const { to='susana', property='', when='', notes='' } = req.body || {};
    const number = to==='susana' ? process.env.CLEANING_SUSANA
                 : to==='paloma' ? process.env.CLEANING_PALOMA
                 : to;
    if (!number) return res.status(400).json({ ok:false, error:'destino vacío' });
    const text = `🧹 LIMPIEZA
Alojamiento: ${property}
Hora: ${when}
${notes?`Notas: ${notes}`:''}

Responde LISTO o INCIDENCIA: ...`;
    try {
      await waSendText(number, text);
      res.json({ ok:true });
    } catch(e) {
      res.status(500).json({ ok:false, error:e.message });
    }
  });

  // Reservations CRUD (mínimo)
  router.get('/reservations', ensureAuth, (req,res)=>{
    const r = readJSON(pathReservations, []);
    res.json({ ok:true, reservations: r });
  });
  router.post('/reservations', ensureAuth, express.json(), (req,res)=>{
    const r = readJSON(pathReservations, []);
    let body = req.body || {};
    if (!body.id) body.id = `res_${Math.random().toString(36).slice(2,8)}_${Date.now().toString(36)}`;
    r.push(body);
    writeJSON(pathReservations, r);
    res.json({ ok:true, id: body.id });
  });
  router.put('/reservations/:id', ensureAuth, express.json(), (req,res)=>{
    const r = readJSON(pathReservations, []);
    const id = req.params.id;
    const ix = r.findIndex(x => x.id === id);
    if (ix === -1) return res.status(404).json({ ok:false, error:'not found' });
    r[ix] = { ...r[ix], ...req.body };
    writeJSON(pathReservations, r);
    res.json({ ok:true });
  });
  router.delete('/reservations/:id', ensureAuth, (req,res)=>{
    const r = readJSON(pathReservations, []);
    const id = req.params.id;
    const n = r.filter(x => x.id !== id);
    writeJSON(pathReservations, n);
    res.json({ ok:true });
  });

  app.use('/api', router);
}
