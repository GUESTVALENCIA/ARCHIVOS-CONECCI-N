// Simple JSON storage helpers
const fs = require('fs');
const path = require('path');

function readJSON(relPath, fallback) {
  const p = path.resolve(process.cwd(), relPath);
  try {
    if (!fs.existsSync(p)) return fallback;
    const raw = fs.readFileSync(p, 'utf8');
    return JSON.parse(raw || 'null') ?? fallback;
  } catch (e) {
    console.error('[storage] read error', relPath, e.message);
    return fallback;
  }
}
function writeJSON(relPath, data) {
  const p = path.resolve(process.cwd(), relPath);
  try {
    const dir = path.dirname(p);
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(p, JSON.stringify(data, null, 2), 'utf8');
    return true;
  } catch (e) {
    console.error('[storage] write error', relPath, e.message);
    return false;
  }
}

module.exports = { readJSON, writeJSON };
