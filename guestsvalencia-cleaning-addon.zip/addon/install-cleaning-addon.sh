#!/usr/bin/env bash
set -euo pipefail

SITE_DIR="${SITE_DIR:-/var/www/guestsvalencia}"
cd "$SITE_DIR"

echo "➡️ Instalando Cleaning Scheduler Addon en $(pwd)"

# Crear carpetas
mkdir -p server/cleaning admin data

# Copiar archivos
cp -f addon/server/cleaning/storage.js server/cleaning/storage.js
cp -f addon/server/cleaning/scheduler.js server/cleaning/scheduler.js
cp -f addon/server/cleaning/api.js server/cleaning/api.js

cp -f addon/admin/cleaning.html admin/cleaning.html

# Data seeds (si no existen)
[ -f data/reservations.json ] || cp addon/data/reservations.json data/reservations.json
[ -f data/cleaning.json ] || cp addon/data/cleaning.json data/cleaning.json
[ -f data/cleaning-settings.json ] || cp addon/data/cleaning-settings.json data/cleaning-settings.json

# Dependencia fetch
cd server
npm pkg get dependencies.node-fetch >/dev/null 2>&1 || npm i node-fetch@3 --silent
cd ..

# Inyectar hooks en server.js (si no existen ya)
if ! grep -q "cleaning/scheduler" server/server.js; then
  echo "🧩 Parchando server/server.js (scheduler/api)…"
  # Insert requires cerca del inicio
  sed -i "1i const cleaningScheduler = require('./cleaning/scheduler');
const cleaningApi = require('./cleaning/api');" server/server.js
  # Insert init antes de app.listen
  if grep -q "app.listen" server/server.js; then
    sed -i "s|app.listen|cleaningApi(app);\ncleaningScheduler.init(app);\n\napp.listen|" server/server.js
  else
    echo "\ncleaningApi(app);\ncleaningScheduler.init(app);" >> server/server.js
  fi
fi

echo "🚀 Reiniciando contenedores…"
docker compose up -d

echo "✅ Addon instalado. Abre /admin/cleaning.html y conecta con tu Backend + ADMIN KEY."
