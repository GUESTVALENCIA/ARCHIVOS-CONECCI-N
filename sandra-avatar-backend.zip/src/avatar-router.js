import express from 'express';
import axios from 'axios';

export const avatarTokenRouter = express.Router();

/**
 * POST /token/avatar
 * Body: { provider: 'heygen' | 'gign' | 'cartesia' }
 * Return: { ok:true, rtcEndpoint, token, iceServers? }
 */
avatarTokenRouter.post('/', async (req, res) => {
  try {
    const provider = (req.body?.provider || '').toLowerCase();
    if (!provider) return res.status(400).json({ ok:false, error:'provider required' });

    let payload;
    switch (provider) {
      case 'heygen':
        payload = await tokenForHeygen();
        break;
      case 'gign':
        payload = await tokenForGign();
        break;
      case 'cartesia':
        payload = await tokenForCartesia();
        break;
      default:
        return res.status(400).json({ ok:false, error:'unsupported provider' });
    }
    return res.json({ ok:true, ...payload });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ ok:false, error: 'avatar token error' });
  }
});

/**
 * Provider: HeyGen (example skeleton)
 * Docs: CONSULTE la documentación oficial de HeyGen para la ruta y payload actual.
 * Env:
 *  - HEYGEN_API_KEY
 *  - HEYGEN_RTC_ENDPOINT (p.ej. https://api.heygen.com/v1/realtime/webrtc or similar)
 */
async function tokenForHeygen() {
  const apiKey = process.env.HEYGEN_API_KEY;
  const rtcEndpoint = process.env.HEYGEN_RTC_ENDPOINT || 'https://api.heygen.com/v1/rtc'; // placeholder
  if (!apiKey) throw new Error('HEYGEN_API_KEY missing');

  // Muchas plataformas exponen un endpoint para crear "session/client_secret" o token temporal.
  // Aquí devolvemos el apiKey directamente como "token" de ejemplo; en producción cree un token efímero.
  const token = apiKey;

  // Opcional: algunos proveedores ofrecen STUN/TURN específicos
  const iceServers = process.env.ICE_JSON ? JSON.parse(process.env.ICE_JSON) : undefined;

  return { rtcEndpoint, token, iceServers };
}

/**
 * Provider: GIGN (example skeleton)
 * Env:
 *  - GIGN_API_KEY
 *  - GIGN_RTC_ENDPOINT
 */
async function tokenForGign() {
  const apiKey = process.env.GIGN_API_KEY;
  const rtcEndpoint = process.env.GIGN_RTC_ENDPOINT || 'https://api.gign.example/rtc'; // placeholder
  if (!apiKey) throw new Error('GIGN_API_KEY missing');
  const token = apiKey;
  const iceServers = process.env.ICE_JSON ? JSON.parse(process.env.ICE_JSON) : undefined;
  return { rtcEndpoint, token, iceServers };
}

/**
 * Provider: Cartesia (example skeleton)
 * Env:
 *  - CARTESIA_API_KEY
 *  - CARTESIA_RTC_ENDPOINT
 */
async function tokenForCartesia() {
  const apiKey = process.env.CARTESIA_API_KEY;
  const rtcEndpoint = process.env.CARTESIA_RTC_ENDPOINT || 'https://api.cartesia.example/rtc'; // placeholder
  if (!apiKey) throw new Error('CARTESIA_API_KEY missing');
  const token = apiKey;
  const iceServers = process.env.ICE_JSON ? JSON.parse(process.env.ICE_JSON) : undefined;
  return { rtcEndpoint, token, iceServers };
}
