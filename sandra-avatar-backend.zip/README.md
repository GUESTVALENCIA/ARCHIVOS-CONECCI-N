# Sandra Avatar Backend (Node/Express)
Router de ejemplo para `/token/avatar` que enruta a **HeyGen | GIGN | Cartesia** según `provider`.

## Rápido
```bash
npm i
cp .env.example .env   # edita claves y endpoints
npm run dev            # http://localhost:8787/healthz
```

## Endpoint
`POST /token/avatar`
```json
{ "provider": "heygen" }   // o "gign", "cartesia"
```
Respuesta:
```json
{ "ok": true, "rtcEndpoint": "https://...", "token": "…", "iceServers": [ ... ] }
```

> ⚠️ Seguridad:
> - **No** expongas API keys largas directamente al navegador. Ideal: emitir **tokens efímeros**.
> - Limita CORS a tu dominio (`CORS_ORIGINS`).
> - Implementa rate-limit si lo despliegas público.

## Notas
- Las URLs y payloads de cada proveedor son **placeholders**. Conéctalos a sus SDK/API oficiales.
- Si el proveedor entrega un `client_secret` temporal, reenvíalo como `token`.
- Si exige STUN/TURN propios, rellena `ICE_JSON`.
