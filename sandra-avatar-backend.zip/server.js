import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import morgan from 'morgan';
import { avatarTokenRouter } from './src/avatar-router.js';

const app = express();
const PORT = process.env.PORT || 8787;

// --- CORS ---
const ALLOWED_ORIGINS = (process.env.CORS_ORIGINS || '').split(',').map(s=>s.trim()).filter(Boolean);
app.use(cors({
  origin: (origin, cb) => {
    if (!origin || ALLOWED_ORIGINS.length === 0 || ALLOWED_ORIGINS.includes(origin)) return cb(null, true);
    return cb(new Error('Not allowed by CORS: ' + origin));
  },
  credentials: false
}));

app.use(express.json({ limit: '1mb' }));
app.use(morgan('tiny'));

// Health
app.get('/healthz', (req, res) => res.json({ ok: true, name: 'sandra-avatar-backend' }));

// --- AVATAR TOKEN ROUTE ---
app.use('/token/avatar', avatarTokenRouter);

// 404
app.use((req, res) => res.status(404).json({ ok:false, error:'Not found' }));

app.listen(PORT, () => {
  console.log(`Sandra avatar backend listening on http://0.0.0.0:${PORT}`);
});
