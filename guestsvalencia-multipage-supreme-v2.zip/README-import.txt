GuestsValencia — Importador de fotos & datos
===========================================

Sube aquí mismo un ZIP con esta estructura por carpetas (un folder por alojamiento):

fotos.zip
├─ montanejos-duplex/
│  ├─ 01-salon.jpg
│  ├─ 02-habitacion.jpg
│  └─ 03-terraza.jpg
├─ valencia-mendez-nunez/
│  ├─ 01-hab1.jpg
│  └─ 02-cocina.jpg
└─ altea-hills-villa/
   ├─ 01-vistas.jpg
   └─ 02-salon.jpg

Y opcionalmente un JSON con temporadas y reglas (si no lo mandas, crearé una base tipo):
properties.json
[
  {
    "id": "montanejos-duplex",
    "name": "Dúplex Montanejos · Fuente de los Baños",
    "location": "Montanejos, Castellón",
    "beds": 3,
    "guests": 6,
    "price": 120,
    "tags": ["♨️ Termales incluidas", "🔐 Acceso digital", "🏞️ Naturaleza"],
    "amenities": ["WiFi","Cerradura digital","Cocina equipada","Calefacción"],
    "seasons": [
      {"name":"Baja","date_from":"2025-01-10","date_to":"2025-03-20","price":110,"min_nights":2},
      {"name":"Media","date_from":"2025-03-21","date_to":"2025-06-14","price":120,"min_nights":2},
      {"name":"Alta","date_from":"2025-06-15","date_to":"2025-09-15","price":150,"min_nights":3}
    ],
    "rules": ["No fiestas","No fumar","Silencio de 22:00 a 08:00"]
  }
]

Cuando lo subas aquí, yo:
1) Copiaré tus fotos reales a /assets/*.jpg.
2) Generaré el data/properties.json final con tus rutas reales de imágenes.
3) Empaquetaré todo en un ZIP “listo para producción”.
