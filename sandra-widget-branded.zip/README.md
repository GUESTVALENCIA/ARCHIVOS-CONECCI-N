# Sandra Widget (Branded · GuestsValencia)
FAB con logo y animación pulse. Instrucciones en comentarios del JS.
