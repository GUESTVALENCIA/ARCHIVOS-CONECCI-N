# 🎨 Sandra Widget · Mini — GuestsValencia Skin

Skin con **toque de marca**: color acento mediterráneo, icono personalizable (por defecto 💙), opción de posición izquierda/derecha, radios suaves y sombra elegante. Mantiene todas las funciones CONNECTED (STT, Voz, Avatar).

## Archivos
- `sandra-mini-connected-gv.js` — versión con skin de marca.
- `README.md` — esta guía.

## Integración
Coloca el JS en tu carpeta pública o CDN y pega el snippet justo antes de `</body>`:

```html
<script src="/sandra-mini-connected-gv.js"
        defer
        data-sandra-mini
        data-backend="https://guestsvalencia.es"
        data-theme="auto"
        data-pills="on"
        data-model="gpt-4o-realtime-preview-2024-12-17"
        data-accent="#007BFF"
        data-icon="💙"
        data-position="right"
        data-radius="18px"
        data-shadow="0 18px 35px rgba(0,0,0,.25)"></script>
```

### Props disponibles (data-*)
- `data-backend` → origen del backend (obligatorio).
- `data-theme` → `auto` | `light` | `dark`.
- `data-pills` → `on` | `off`.
- `data-model` → modelo Realtime de OpenAI.
- `data-accent` → color del botón/CTA (hex, rgb, hsl).
- `data-icon` → emoji o caracter para el botón y título (por defecto 💙).
- `data-position` → `right` | `left` (dock del botón y popover).
- `data-radius` → radio del popover (ej. `12px`, `18px`).
- `data-shadow` → sombra CSS del botón/panel.

## Requisitos Backend
Igual que el mini conectado estándar:
- `GET /token/realtime?model=...` → token efímero (`client_secret`|`token`).
- `GET /token/avatar` → `{ rtcEndpoint, token }` del proveedor.
- `wss://tu_dominio/ws/stt` para dictado (o fallback Web Speech API).

## Consejos de estilo
- Mantén el `accent` dentro de la paleta GuestsValencia para coherencia.
- Si usas logo SVG, puedes reemplazar `data-icon` por `💙` y añadir el SVG dentro del botón tras carga si lo prefieres (hook de inicialización externa).

## Troubleshooting rápido
- Permisos de micrófono, proxy WS, autoplay (primer click) y tokens efímeros igual que la versión base.
