# 🖼️ Sandra Widget · Mini — GV Skin con Logo SVG

Esta build permite usar **tu logo en SVG** en el botón del widget, manteniendo todas las funciones CONNECTED (STT, Voz, Avatar).

## Archivos
- `sandra-mini-connected-gv-logo.js` — versión con soporte SVG.
- `README.md` — esta guía.

## Integración
1) Sube tu logo, por ejemplo a `/assets/gv-logo.svg` (mismo dominio o CDN con CORS permitido).
2) Inserta el script justo antes de `</body>`:

```html
<script src="/sandra-mini-connected-gv-logo.js"
        defer
        data-sandra-mini
        data-backend="https://guestsvalencia.es"
        data-theme="auto"
        data-pills="on"
        data-model="gpt-4o-realtime-preview-2024-12-17"
        data-accent="#007BFF"
        data-icon="💙"
        data-icon-src="/assets/gv-logo.svg"
        data-logo-size="22"
        data-position="left"
        data-radius="18px"
        data-shadow="0 18px 35px rgba(0,0,0,.25)"
        data-badge="mini"></script>
```

- Si `data-icon-src` falla (CORS/404), el botón usa el **emoji/texto** definido en `data-icon` como **fallback**.
- Ajusta `data-logo-size` para escalar el SVG (en px).

## Requisitos Backend
- Igual que las otras builds: `/token/realtime`, `/token/avatar`, y `wss://.../ws/stt`.

## Consejos
- Para SVG con trazo/relleno oscuros, asegúrate de que se vea bien sobre el botón con acento; si no, exporta una versión en blanco o usa `currentColor` en tu SVG y el color heredará `#fff` del botón.
