module.exports = {
  apps: [{
    name: "guestsvalencia",
    script: "server.js",
    cwd: "./server",
    env: {
      ADMIN_KEY: "pon_una_clave_muy_segura_aqui",
      CORS_ORIGINS: "https://guestsvalencia.es,https://www.guestsvalencia.es",
      PORT: 3000
    }
  }]
};
