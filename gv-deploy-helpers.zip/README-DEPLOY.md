# Despliegue rápido GuestsValencia

## Opción A · Docker (recomendada)
1) Copia **guestsvalencia-admin-ready.zip** al servidor y descomprímelo en `/var/www/guestsvalencia`.
2) Copia **gv-deploy-helpers.zip** y descomprímelo en el **mismo** directorio.
3) Edita `docker-compose.yml` y pon un `ADMIN_KEY` fuerte.
4) `docker compose up -d`
   - Caddy saca HTTPS automático (Let's Encrypt).
   - La web + panel admin estarán en https://guestsvalencia.es/ (panel en `/admin/`).

## Opción B · PM2 + Caddy/Nginx
1) Instala Node 20 y PM2: `curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash - && sudo apt -y install nodejs && sudo npm i -g pm2`
2) Sitio en `/var/www/guestsvalencia` (copia y descomprime el ZIP allí).
3) `cp /var/www/guestsvalencia/server/.env.example /var/www/guestsvalencia/server/.env` y rellena `ADMIN_KEY` y `CORS_ORIGINS`.
4) En la raíz del proyecto, crea `pm2.config.cjs` (incluido en este ZIP) y ejecuta: `pm2 start pm2.config.cjs && pm2 save`
5) Proxy inverso con Caddy o Nginx hacia `http://127.0.0.1:3000` (archivo `Caddyfile` incluido).

## Nota sobre la edición de la web
- Panel: https://guestsvalencia.es/admin/
- En la esquina superior derecha define:
  - Backend: https://guestsvalencia.es
  - ADMIN KEY: la de tu `.env` / compose
- Desde **Alojamientos** edita, sube fotos y guarda (escribe `data/properties.json`).
- **Web & CMS** modifica textos (`data/cms.json`).  
- **Sandra** ajusta endpoints y modelo (`data/sandra.json`).
- **Exportar** te genera un ZIP descargable de tu sitio tal como está en el servidor.

¡Listo! Cualquier duda, dime y lo ajusto.
