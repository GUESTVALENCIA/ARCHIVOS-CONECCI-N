// GuestsValencia basic frontend logic
async function loadProperties(){
  const res = await fetch('data/properties.json');
  return res.json();
}
function formatEUR(n){ return new Intl.NumberFormat('es-ES',{style:'currency',currency:'EUR',maximumFractionDigits:0}).format(n); }
async function renderListings(containerId, filters={}){
  const el = document.getElementById(containerId);
  if(!el) return;
  const props = await loadProperties();
  const filtered = props.filter(p => {
    if(filters.tag && !p.tags.join(' ').includes(filters.tag)) return false;
    if(filters.q && !p.name.toLowerCase().includes(filters.q.toLowerCase()) && !p.location.toLowerCase().includes(filters.q.toLowerCase())) return false;
    return true;
  });
  el.innerHTML = filtered.map(p => `
    <article class="card">
      <a href="listing.html?id=${encodeURIComponent(p.id)}">
        <div class="img"><img src="assets/${p.images[0]}" alt="${p.name}" style="width:100%;height:100%;object-fit:cover"/></div>
      </a>
      <div class="body">
        <h3 class="title"><a href="listing.html?id=${encodeURIComponent(p.id)}">${p.name}</a></h3>
        <div class="meta">${p.location} · 🛏️ ${p.beds} · 👥 ${p.guests}</div>
        <div class="tags">${p.tags.map(t=>`<span class="tag">${t}</span>`).join('')}</div>
        <div class="price">${formatEUR(p.price)}/noche</div>
      </div>
    </article>
  `).join('');
}
async function renderListingDetail(){
  const params = new URLSearchParams(location.search);
  const id = params.get('id');
  if(!id) return;
  const props = await loadProperties();
  const p = props.find(x => x.id === id);
  if(!p) return;
  document.getElementById('title').textContent = p.name;
  document.getElementById('subtitle').textContent = `${p.location} · 🛏️ ${p.beds} · 👥 ${p.guests}`;
  const gal = document.getElementById('gallery');
  gal.innerHTML = p.images.map(src => `<img src="assets/${src}" alt="${p.name}">`).join('');
  document.getElementById('desc').textContent = p.description;
  document.getElementById('amenities').innerHTML = p.amenities.map(a=>`<span class="tag">${a}</span>`).join('');
  document.getElementById('price').textContent = formatEUR(p.price) + '/noche';
  const lb = document.querySelector('.lightbox');
  gal.querySelectorAll('img').forEach(img=>{
    img.addEventListener('click', ()=>{ lb.querySelector('img').src = img.src; lb.classList.add('show'); });
  });
  lb.addEventListener('click', ()=> lb.classList.remove('show'));
  const propSel = document.getElementById('prop');
  if(propSel){ propSel.value = p.name; document.getElementById('prop').value = p.name; }
}
function hookBooking(formId){
  const form = document.getElementById(formId);
  if(!form) return;
  form.addEventListener('submit', (e)=>{
    e.preventDefault();
    const data = Object.fromEntries(new FormData(form));
    alert(`Solicitud enviada:\n${data.prop}\n${data.checkin} → ${data.checkout}\n${data.guests} huésped(es)\n\nSandra te contactará para confirmar.`);
  });
}
window.GV = { renderListings, renderListingDetail, hookBooking };


async function postJSON(url, data){
  try{
    const r = await fetch(url, { method: 'POST', headers: { 'Content-Type':'application/json' }, body: JSON.stringify(data) });
    if(!r.ok) throw new Error('HTTP '+r.status);
    return await r.json().catch(()=>({ok:true}));
  }catch(e){
    console.warn('POST error', e);
    return { ok:false, error: String(e) };
  }
}

function backendBase(){
  return (typeof window !== 'undefined' && window.GV_BACKEND) ? window.GV_BACKEND.replace(/\/$/,'') : null;
}

function hookBooking(formId){
  const form = document.getElementById(formId);
  if(!form) return;
  form.addEventListener('submit', async (e)=>{
    e.preventDefault();
    const data = Object.fromEntries(new FormData(form));
    const base = backendBase();
    if(base){
      const res = await postJSON(base + '/api/reservas', data);
      if(res.ok !== false){ alert('¡Gracias! 💙 Te contactaremos para confirmar.'); form.reset(); return; }
    }
    alert(`Solicitud enviada:\n${data.prop}\n${data.checkin} → ${data.checkout}\n${data.guests} huésped(es)`);
  });
}

function hookContact(formId){
  const form = document.getElementById(formId);
  if(!form) return;
  form.addEventListener('submit', async (e)=>{
    e.preventDefault();
    const data = Object.fromEntries(new FormData(form));
    const base = backendBase();
    if(base){
      const res = await postJSON(base + '/api/email', data);
      if(res.ok !== false){ alert('¡Gracias! 💙 Te responderemos pronto.'); form.reset(); return; }
    }
    alert('Gracias 💙 te responderemos pronto.');
  });
}

window.GV = Object.assign(window.GV || {}, { hookBooking, hookContact });
