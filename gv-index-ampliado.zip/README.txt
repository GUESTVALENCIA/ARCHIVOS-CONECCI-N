GuestsValencia · index ampliado
--------------------------------
• Este index elimina FABs/modales antiguos de Sandra y añade la sección "Reservas directas".
• El widget flotante se carga desde /sandra-mini-gv-supreme.js — sustituye la ruta por tu build real.
• El logo SVG está en assets/gv-logo.optimized.svg (hereda currentColor).
