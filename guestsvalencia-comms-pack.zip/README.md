
# GuestsValencia · Comms Pack (Voice/Text/Avatar + Listings)
- Diseño sin FABs, botones redondeados elegantes.
- Barra de comunicaciones fija: 🎙 mic (STT WS), ■ stop, 🗣 voz (Realtime token), 🧑‍🚀 avatar (WebRTC), 💬 WhatsApp.
- Drawer del Prompt Maestro (Ctrl+M o botón).

## Endpoints esperados (backend)
- `GET  /token/realtime` → `{ client_secret: "..." }`
- `GET  /token/avatar` → `{ rtcEndpoint: "https://...", token: "..." }` (o solo `rtcEndpoint`)
- `WS   /ws/stt` → recibe PCM16LE y envía transcripciones (tu servidor)
- `PUT  /api/sandra/prompt` (x-admin-key) → guarda `data/sandra.json`

## Instalación
```bash
scp -r guestsvalencia-comms-pack.zip usuario@TU_SERVIDOR:/var/www/guestsvalencia/
ssh usuario@TU_SERVIDOR 'cd /var/www/guestsvalencia && unzip -o guestsvalencia-comms-pack.zip'
```
Asegúrate de servir `/css`, `/js`, `/data` y `/assets`.

## Listados
Edita `data/listings.json` con tus 9 alojamientos. Los placeholders `assets/hero/fake-valencia-*.jpg` los puedes reemplazar por tus fotos.
