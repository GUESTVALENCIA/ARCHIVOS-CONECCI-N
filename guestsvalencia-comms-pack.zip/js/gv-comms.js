
window.GV = (function(){
  const BACKEND = window.GV_BACKEND || "https://guestsvalencia.es";
  const WA_NUMBER = window.GV_WHATSAPP || "+34611122334"; // reemplaza por el oficial
  const MODEL_REALTIME = "gpt-4o-realtime-preview-2024-12-17"; // ❤️ GPT-4o (no 5)

  function waLink(text){ return "https://wa.me/" + WA_NUMBER.replace(/\D/g,'') + "?text=" + encodeURIComponent(text||"Hola Sandra, ¿disponible?"); }

  async function loadListings(){
    try{
      const r = await fetch('/data/listings.json', {cache:'no-store'});
      const items = await r.json();
      const el = document.getElementById('cardsListings');
      if (!el) return;
      el.innerHTML = items.map(x => `
        <a class="card" href="/checkout.html?lid=${encodeURIComponent(x.id)}">
          <img src="${x.cover}" alt="${x.title}">
          <div class="pad">
            <div class="pill">${x.area} · ${x.summary}</div>
            <strong>${x.title}</strong>
            <span class="ghost">${x.amenities.join(' · ')}</span>
          </div>
        </a>
      `).join('');
    }catch(e){ console.warn('No listings yet', e); }
  }

  // === Prompt Maestro Drawer ===
  const PM_DEFAULT = String.raw`## Modos de conversación
- modo=ops → operativo: reservas, limpieza, incidencias, pagos (directa y concisa).
- modo=concierge → asesoría de barrio (cercana, resolutiva).
- modo=social → charla ligera (máx. 2–3 turnos), regresa a tarea.

## Reglas
- Sin reseñas; claridad de check-in/out y reglas de casa.
- No prometas disponibilidad sin backend.
- Nunca compartir tokens ni ADMIN_KEY.
- Guardar en memoria: idioma, preferencia zona playa/centro, check-in autónomo, pax habitual.

## Contacto
- WhatsApp botón superior y email info@guestsvalencia.es
`;

  async function initPromptDrawer(){
    const drawer = document.getElementById('drawer');
    const ta = document.getElementById('promptText');
    const backendInput = document.getElementById('backendUrl');
    const keyInput = document.getElementById('adminKey');
    const copyBtn = document.getElementById('copyPrompt');
    const saveBtn = document.getElementById('savePrompt');
    const openBtn = document.getElementById('btnPrompt');
    const closeBtn = document.getElementById('closeDrawer');

    function open(){ drawer?.classList.add('open'); }
    function close(){ drawer?.classList.remove('open'); }
    openBtn?.addEventListener('click', open);
    closeBtn?.addEventListener('click', close);

    let ctrl=false;
    window.addEventListener('keydown',(e)=>{ if(e.key==='Control') ctrl=true; if(ctrl && e.key.toLowerCase()==='m'){ e.preventDefault(); open(); }});
    window.addEventListener('keyup',(e)=>{ if(e.key==='Control') ctrl=false; });

    try{
      const r = await fetch('/data/sandra.json',{cache:'no-store'});
      if(r.ok){ const j=await r.json(); ta.value = j.prompt || PM_DEFAULT; } else { ta.value = PM_DEFAULT; }
    }catch{ ta.value = PM_DEFAULT; }

    copyBtn?.addEventListener('click', async ()=>{
      await navigator.clipboard.writeText(ta.value);
      copyBtn.textContent = '¡Copiado!'; setTimeout(()=> copyBtn.textContent='Copiar', 900);
    });
    saveBtn?.addEventListener('click', async ()=>{
      const base = (backendInput.value || location.origin).replace(/\/$/,'');
      const key = keyInput.value.trim(); if(!key){ alert('Pon tu ADMIN KEY'); return; }
      const r = await fetch(base + '/api/sandra/prompt', { method:'PUT', headers:{'Content-Type':'application/json','x-admin-key':key}, body: JSON.stringify({prompt: ta.value}) });
      alert(r.ok? 'Guardado ✔' : 'Error al guardar');
    });

    if (location.hash === '#openPrompt') open();
  }

  // === Unified Comms (Voice / Text / Avatar / WhatsApp) ===
  let mediaStream = null;
  let ws = null;

  async function startMic(wsUrl){
    try{
      mediaStream = await navigator.mediaDevices.getUserMedia({ audio:true });
      const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      const source = audioCtx.createMediaStreamSource(mediaStream);
      const processor = audioCtx.createScriptProcessor(4096, 1, 1);
      source.connect(processor);
      processor.connect(audioCtx.destination);
      ws = new WebSocket(wsUrl.replace(/^http/,'ws'));
      ws.binaryType = 'arraybuffer';
      ws.onopen = ()=> console.log('WS open');
      ws.onclose = ()=> console.log('WS close');
      processor.onaudioprocess = e => {
        if (ws && ws.readyState === 1){
          const input = e.inputBuffer.getChannelData(0);
          // Convert float32 → PCM16 Little Endian
          const buf = new ArrayBuffer(input.length*2);
          const view = new DataView(buf);
          for (let i=0;i<input.length;i++){
            let s = Math.max(-1, Math.min(1, input[i]));
            view.setInt16(i*2, s < 0 ? s*0x8000 : s*0x7fff, true);
          }
          ws.send(buf);
        }
      };
      return { ok:true };
    }catch(e){
      console.error(e); return { ok:false, error: e.message };
    }
  }

  function stopMic(){
    if (mediaStream){ mediaStream.getTracks().forEach(t=>t.stop()); mediaStream=null; }
    if (ws){ try{ ws.close(); }catch{} ws=null; }
  }

  // Avatar modal (WebRTC token/endpoint handled server-side)
  async function openAvatar(){
    const modal = document.getElementById('avatarModal');
    const frame = document.getElementById('avatarFrame');
    modal.classList.add('open');
    try{
      const r = await fetch(BACKEND + '/token/avatar');
      const j = await r.json();
      if (j?.rtcEndpoint){
        frame.src = j.rtcEndpoint + (j.token ? ('?token=' + encodeURIComponent(j.token)) : '');
      } else {
        frame.srcdoc = '<div style="display:flex;align-items:center;justify-content:center;height:100%;color:#eaeaea">Configura /token/avatar en el backend</div>';
      }
    }catch{
      frame.srcdoc = '<div style="display:flex;align-items:center;justify-content:center;height:100%;color:#eaeaea">No disponible</div>';
    }
  }
  function closeAvatar(){
    const modal = document.getElementById('avatarModal');
    const frame = document.getElementById('avatarFrame');
    modal.classList.remove('open'); frame.src='about:blank';
  }

  function initCommsUI(){
    const micBtn = document.getElementById('btnMic');
    const stopBtn = document.getElementById('btnStop');
    const txtBtn = document.getElementById('btnText');
    const waBtn = document.getElementById('btnWA');
    const avBtn = document.getElementById('btnAvatar');

    waBtn && (waBtn.href = waLink("Hola Sandra, ¿me ayudas con una reserva?"));

    micBtn?.addEventListener('click', async ()=>{
      const u = BACKEND + '/ws/stt'; // tu WS de STT
      const res = await startMic(u);
      const dot = document.getElementById('dot');
      if (res.ok){ dot.className='dot ok'; } else { dot.className='dot warn'; alert('Mic: ' + (res.error||'error')); }
    });
    stopBtn?.addEventListener('click', ()=>{ stopMic(); const dot = document.getElementById('dot'); dot.className='dot'; });

    // TTS/Reatime: pedir token efímero y abrir una pestaña reproductora simple
    txtBtn?.addEventListener('click', async ()=>{
      try{
        const r = await fetch(BACKEND + '/token/realtime');
        const j = await r.json();
        if (j?.client_secret){
          const w = window.open('', '_blank', 'width=420,height=200');
          w.document.write('<pre style="padding:12px;background:#0e0e10;color:#eaeaea">Token recibido. Inicia cliente Realtime para ' + MODEL_REALTIME + '.</pre>');
        } else {
          alert('Configura /token/realtime en el backend');
        }
      }catch{ alert('No disponible'); }
    });

    avBtn?.addEventListener('click', openAvatar);
    document.getElementById('closeAvatar')?.addEventListener('click', closeAvatar);
  }

  function init(){
    loadListings();
    initCommsUI();
    initPromptDrawer();
  }

  return { init };
})();

document.addEventListener('DOMContentLoaded', GV.init);
