#!/usr/bin/env bash
set -euo pipefail

SITE_DIR="${SITE_DIR:-/var/www/guestsvalencia}"
cd "$SITE_DIR"

echo "➡️ Instalando Conversation Modes Addon en: $(pwd)"
mkdir -p server/modes addon-modes data

# Copiar archivos
cp -f addon-modes/server/modes/modes.js server/modes/modes.js
cp -f addon-modes/server/modes/api.js server/modes/api.js
cp -f addon-modes/README.md addon-modes/README.md 2>/dev/null || true

# Conectar API en server.js
if ! grep -q "modes/api" server/server.js; then
  echo "🧩 Conectando modesApi en server/server.js"
  sed -i "1i const modesApi = require('./modes/api');
const modes = require('./modes/modes');" server/server.js
  if grep -q "app.listen" server/server.js; then
    sed -i "s|app.listen|modesApi(app, ensureAuth);\n\napp.listen|" server/server.js
  else
    echo "\nmodesApi(app, ensureAuth);" >> server/server.js
  fi
else
  echo "ℹ️ modesApi ya estaba conectado."
fi

# Parchear webhook de WhatsApp (best-effort)
if grep -q "app.post(\'/webhooks/whatsapp'" server/server.js; then
  if grep -q "modes\." server/server.js; then
    echo "ℹ️ Piezas de modes ya presentes."
  else
    echo "🔧 Inyectando helpers de modes en webhook…"
    # Inserta require de modes si no está (lo pusimos arriba, pero por si acaso)
    grep -q "require('./modes/modes')" server/server.js || sed -i "1i const modes = require('./modes/modes');" server/server.js

    # Tras obtener 'from' y 'text', añadimos sesión + intent + guardado
    sed -i "/const text *= *.*;\|text:\s*{\s*body:/,/(\}|\))\s*;/{0,/}/ s//&\n    try {\n      const subject = 'whatsapp:+' + (String(from||'').replace(/\\D/g,''));\n      let sess = modes.getSession(subject);\n      const intent = modes.detectIntent(text||'');\n      sess = modes.applyMode(sess, intent);\n      sess = modes.injectGuidance(sess);\n      modes.saveSession(subject, sess);\n      if (app.locals && typeof app.locals.memCapture === 'function') {\n        try { await app.locals.memCapture('+' + String(from||'').replace(/\\D/g,''), text||''); } catch {}\n      }\n    } catch(e) { /* noop */ }\n/" server/server.js || true
  fi
else
  echo "⚠️ No se encontró '/webhooks/whatsapp' para parchear automáticamente."
  echo "   Inserta manualmente dentro del handler, tras calcular from/text:"
  cat <<'SNIP'
    const subject = 'whatsapp:+' + (String(from||'').replace(/\D/g,''));
    let sess = modes.getSession(subject);
    const intent = modes.detectIntent(text||'');
    sess = modes.applyMode(sess, intent);
    sess = modes.injectGuidance(sess);
    modes.saveSession(subject, sess);
    if (app.locals && typeof app.locals.memCapture === 'function') {
      try { await app.locals.memCapture('+' + String(from||'').replace(/\D/g,''), text||''); } catch {}
    }
SNIP
fi

echo "🐳 Reiniciando contenedores…"
docker compose up -d

echo "✅ Modes Addon instalado."
echo "   Endpoints: /api/modes/session/:subject — /api/modes/mode/:subject"
