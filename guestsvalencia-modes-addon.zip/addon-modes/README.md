# GuestsValencia · Conversation Modes Addon (ops / concierge / social)

Este addon añade **modos de conversación** para Sandra:
- `ops` → gestión/operativa (reservas, pagos, limpieza).
- `concierge` → recomendaciones y dudas de barrio.
- `social` → charla ligera limitada (2–3 turnos), con retorno automático a la tarea.

Incluye:
- `server/modes/modes.js` → lógica de selección y límites.
- `server/modes/api.js` → endpoints para consultar/cambiar modo y ver la sesión.
- Instalador que conecta la API y **parchea el webhook de WhatsApp** para:
  - Resolver `subject_id` y cargar/guardar `session`.
  - Detectar y alternar el modo según heurísticas o comandos: `modo: ops|concierge|social`.
  - Aplicar **límite de turnos social** y redirección suave a la tarea.
  - (Opcional) Invocar `app.locals.memCapture` si está disponible (Memory Addon).

## Instalación rápida
```bash
cd /var/www/guestsvalencia
unzip -o guestsvalencia-modes-addon.zip
bash addon-modes/install-modes-addon.sh
```

## Endpoints
- `GET  /api/modes/session/:subject` (admin) → muestra la sesión y modo actual.
- `PUT  /api/modes/mode/:subject` (admin, JSON `{mode}`) → fuerza modo `ops|concierge|social`.
