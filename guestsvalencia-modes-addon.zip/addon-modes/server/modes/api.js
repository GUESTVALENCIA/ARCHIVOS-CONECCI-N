const express = require('express');
const { getSession, saveSession } = require('./modes');

module.exports = function(app, ensureAuth){
  const r = express.Router();

  // Ver sesión actual (admin)
  r.get('/modes/session/:subject', ensureAuth, (req,res)=>{
    const s = getSession(req.params.subject);
    res.json({ ok:true, session: s });
  });

  // Forzar modo (admin)
  r.put('/modes/mode/:subject', ensureAuth, express.json(), (req,res)=>{
    const { mode } = req.body || {};
    if (!['ops','concierge','social'].includes(mode||'')) {
      return res.status(400).json({ ok:false, error:'mode inválido' });
    }
    const s = getSession(req.params.subject);
    s.mode = mode;
    if (mode !== 'social') s.social_turns = 0;
    saveSession(req.params.subject, s);
    res.json({ ok:true, session: s });
  });

  app.use('/api', r);
};
