// Simple file-backed session store + mode heuristics
const fs = require('fs');
const path = require('path');

const SESS_PATH = 'data/sessions.json';

function readJSON(rel, fallback){
  try{
    const p = path.resolve(process.cwd(), rel);
    if (!fs.existsSync(p)) return fallback;
    return JSON.parse(fs.readFileSync(p,'utf8')||'null') ?? fallback;
  }catch(_){ return fallback; }
}
function writeJSON(rel, data){
  const p = path.resolve(process.cwd(), rel);
  fs.mkdirSync(path.dirname(p), { recursive:true });
  fs.writeFileSync(p, JSON.stringify(data, null, 2), 'utf8');
}

function getSession(subject_id){
  const all = readJSON(SESS_PATH, {});
  if (!all[subject_id]) all[subject_id] = { mode:'ops', social_turns:0, updated_at: new Date().toISOString() };
  return all[subject_id];
}
function saveSession(subject_id, sess){
  const all = readJSON(SESS_PATH, {});
  all[subject_id] = { ...(all[subject_id]||{}), ...sess, updated_at: new Date().toISOString() };
  writeJSON(SESS_PATH, all);
  return all[subject_id];
}

function clampSocial(sess){
  // Máximo 3 turnos sociales seguidos
  if (sess.mode === 'social' && sess.social_turns >= 3){
    sess.mode = 'ops';
    sess.social_turns = 0;
    sess.notice = 'volviendo a gestión';
  }
  return sess;
}

function detectIntent(text){
  const t = (text||'').toLowerCase();
  // Comandos explícitos
  if (/^\s*modo:\s*ops\b/.test(t)) return 'ops';
  if (/^\s*modo:\s*concierge\b/.test(t)) return 'concierge';
  if (/^\s*modo:\s*social\b/.test(t)) return 'social';

  // Heurísticas simples
  const opsHints = /(reserva|reservar|precio|pago|check\s*-?in|check\s*-?out|factura|pol[ií]tica|cancelaci[óo]n|disponible|disponibilidad|noche[s]?|habitaci[óo]n|apartamento|limpieza|incidencia)/i;
  const conciergeHints = /(restaurante|recomendaci[oó]n|plan|playa|barrio|transporte|metro|autob[uú]s|aparcar|parking|visitar|museo)/i;
  const socialHints = /(jaja|jeje|jajaj|gracias|buen(s|@) d[ií]as|buenas|hola|qué tal|como est[aá]s|me encanta|jiji|xd)/i;

  if (opsHints.test(t)) return 'ops';
  if (conciergeHints.test(t)) return 'concierge';
  if (socialHints.test(t)) return 'social';
  return null; // no cambiar
}

function applyMode(sess, intent){
  if (!intent) return sess;
  if (intent === 'social'){
    if (sess.mode === 'social') sess.social_turns = (sess.social_turns||0) + 1;
    else { sess.mode = 'social'; sess.social_turns = 1; }
  } else {
    sess.mode = intent;
    if (intent !== 'social') sess.social_turns = 0;
  }
  return clampSocial(sess);
}

function injectGuidance(sess){
  // Añade una guía que la capa de respuesta puede leer para matizar el tono
  if (sess.mode === 'ops'){
    sess.guidance = 'responder directo y conciso; pedir fechas/pax/email/telefono cuando aplique; emojis <=1';
  } else if (sess.mode === 'concierge'){
    sess.guidance = 'recomendar con bullets, claridad y cercanía; 1 emoji opcional; cerrar con CTA de reserva';
  } else if (sess.mode === 'social'){
    sess.guidance = 'charla breve, humor suave; no coquetear; 1-2 turnos y volver a la tarea';
  }
  return sess;
}

module.exports = {
  getSession, saveSession, detectIntent, applyMode, injectGuidance
};
