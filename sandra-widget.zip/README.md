# Sandra Widget (Floating Assistant)

Widget compacto para incrustar en la web (extremo inferior derecho).