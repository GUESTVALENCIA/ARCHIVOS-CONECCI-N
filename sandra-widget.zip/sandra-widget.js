/* Sandra Widget (GuestsValencia) */
console.log("Sandra Widget ready - insert full code here as in previous cell");