# ✨ Sandra Widget · Mini — GuestsValencia SUPREME

Edición “supreme” con extra pulido visual, accesibilidad, opciones de layout y *analytics hooks*. Mantiene todas las funciones CONNECTED (STT, Voz Realtime, Avatar).

## Archivos
- `sandra-mini-gv-supreme.js` → build principal
- `gv-logo.optimized.svg` → logo recomendado (hereda `currentColor`)
- `README.md` → guía rápida

## Snippet básico
```html
<script src="/sandra-mini-gv-supreme.js"
        defer
        data-sandra-mini
        data-backend="https://guestsvalencia.es"
        data-theme="auto"
        data-pills="on"
        data-model="gpt-4o-realtime-preview-2024-12-17"
        data-icon-src="/assets/gv-logo.optimized.svg"
        data-logo-size="22"
        data-accent="#007BFF"
        data-position="right"
        data-offset="16"
        data-radius="18px"
        data-shadow="0 18px 35px rgba(0,0,0,.25)"
        data-z="2147483000"
        data-badge="mini"
        data-copy="on"
        data-start-open="false"></script>
```

### Atributos (`data-*`)
- **`data-backend`** (req): tu dominio backend
- `data-theme`: `auto` | `light` | `dark`
- `data-pills`: `on` | `off`
- `data-model`: modelo Realtime de OpenAI
- `data-icon` / **`data-icon-src`**: emoji de fallback / SVG
- `data-logo-size`: tamaño del logo (px)
- `data-accent`: color acento del botón/CTA
- `data-position`: `left` | `right`
- **`data-offset`**: separación desde bordes (px) → útil para evitar banners de cookies
- `data-radius`, `data-shadow`, **`data-z`**
- `data-badge`: texto del badge (o vacío `""` para ocultar)
- `data-copy`: `on`/`off` (muestra/oculta botón Copiar)
- `data-start-open`: `true` para abrir el popover al cargar

### Accesibilidad
- ARIA en el popover, **focus ring** visible, cierre con **Esc**, *prefers-reduced-motion* respeta animaciones.

### Analytics hooks
Se emiten `CustomEvent` en `window`:
- `sandra:open`, `sandra:close`
- `sandra:send` ({ text })
- `sandra:copy` ({ text })
- `sandra:stt:start|end|stop|error`
- `sandra:voice:start|ready|stop|error`
- `sandra:avatar:start|ready|stop|error`

```js
window.addEventListener("sandra:send", (e) => {
  // Ejemplo: gtag('event','sandra_send', e.detail);
  console.log("Sandra send:", e.detail);
});
```

### Seguridad / CSP
- Sin `eval` ni `Function` constructor.
- Requiere permisos para `connect-src` al backend y OpenAI Realtime.
- Si sirves el SVG desde CDN, habilita CORS y `img-src`/`font-src` según tu CSP.

### Proxy (Caddy ejemplo)
```caddyfile
guestsvalencia.es {
  encode gzip
  reverse_proxy /ws/* 127.0.0.1:8080 {
    header_up Host {host}
  }
  reverse_proxy /token/* 127.0.0.1:8080
  reverse_proxy /api/* 127.0.0.1:8080
  reverse_proxy / 127.0.0.1:3000
}
```

### Troubleshooting
- Permisos de micro, autoplay (primer click), tokens efímeros (`/token/realtime`), y endpoint de avatar (`/token/avatar`).
