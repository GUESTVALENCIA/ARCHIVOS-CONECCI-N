
window.GV_CONFIG = {
  BACKEND: "https://guestsvalencia.es",
  WHATSAPP_MAIN: "+34624829117",        // número oficial
  WHATSAPP_SUSANA: "+34611122334",      // staff (placeholder)
  WHATSAPP_PALOMA: "+34622233445"       // staff (placeholder)
};
