/* Sandra Widget · Mini (CONNECTED)
 * Lightweight, zero-dependency widget to embed Sandra in any site.
 * Features (wired to your backend):
 *  - 🎙️ Dictation via WebSocket to /ws/stt (fallback: Web Speech API)
 *  - 🗣️ Realtime voice via ephemeral token from /token/realtime (WebRTC to OpenAI)
 *  - 🎬 Avatar via /token/avatar (RTC to your provider)
 *
 * Usage:
 * <script src="/sandra-mini-connected.js" defer
 *         data-backend="https://guestsvalencia.es"
 *         data-theme="auto"
 *         data-pills="on"
 *         data-model="gpt-4o-realtime-preview-2024-12-17"></script>
 */
(function () {
  const script = document.currentScript || document.querySelector('script[src*="sandra-mini-connected.js"]');
  if (!script) { console.warn("[SandraMini] Script tag not found."); return; }
  const cfg = {
    backend: script.dataset.backend || location.origin,
    theme: (script.dataset.theme || "auto").toLowerCase(),
    pills: (script.dataset.pills || "on").toLowerCase() === "on",
    model: script.dataset.model || "gpt-4o-realtime-preview-2024-12-17",
  };

  // ---- Styles (tiny, inline, avoids CSS collisions) ----
  const css = `
  .sandra-mini-btn{position:fixed;right:16px;bottom:16px;width:56px;height:56px;border-radius:999px;display:flex;align-items:center;justify-content:center;border:none;cursor:pointer;box-shadow:0 6px 20px rgba(0,0,0,.2);z-index:2147483000;background:#111;color:#fff;font-weight:700;font-family:ui-sans-serif,system-ui;transition:transform .2s ease;}.sandra-mini-btn:hover{transform:translateY(-1px);}
  .sandra-mini-pop{position:fixed;right:16px;bottom:84px;width:320px;max-width:90vw;background:var(--sandra-bg,#fff);color:var(--sandra-fg,#111);border-radius:16px;box-shadow:0 20px 40px rgba(0,0,0,.25);padding:12px;z-index:2147483000;font:14px/1.4 ui-sans-serif,system-ui;}
  .sandra-mini-row{display:flex;gap:8px;align-items:center;justify-content:space-between}
  .sandra-mini-title{font-weight:700;font-size:14px}
  .sandra-mini-chip{font-size:10px;padding:2px 6px;border-radius:999px;background:rgba(0,0,0,.06);}
  .sandra-mini-pills{display:flex;gap:6px;flex-wrap:wrap;margin:8px 0}
  .sandra-mini-pill{border:1px solid rgba(0,0,0,.1);padding:6px 8px;border-radius:999px;cursor:pointer;background:transparent}
  .sandra-mini-area{width:100%;min-height:56px;max-height:140px;resize:vertical;padding:8px;border:1px solid rgba(0,0,0,.12);border-radius:10px;background:transparent;color:inherit}
  .sandra-mini-actions{display:flex;gap:8px;justify-content:flex-end;margin-top:8px}
  .sandra-mini-ghost{border:1px solid rgba(0,0,0,.12);background:transparent;border-radius:10px;padding:8px 10px;cursor:pointer}
  .sandra-mini-solid{border:none;background:#111;color:#fff;border-radius:10px;padding:8px 12px;cursor:pointer}
  .sandra-mini-small{font-size:11px;opacity:.8}
  .sandra-mini-hide{display:none !important}
  `;
  const style = document.createElement("style"); style.textContent = css; document.head.appendChild(style);

  // ---- Theme (auto / light / dark) ----
  const root = document.documentElement;
  function applyTheme() {
    const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
    const dark = cfg.theme === "dark" || (cfg.theme === "auto" && prefersDark);
    root.style.setProperty("--sandra-bg", dark ? "#0b0b0c" : "#ffffff");
    root.style.setProperty("--sandra-fg", dark ? "#f5f6f7" : "#0b0b0c");
  }
  applyTheme();
  if (cfg.theme === "auto" && window.matchMedia) {
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', applyTheme);
  }

  // ---- Elements ----
  const btn = document.createElement("button");
  btn.className = "sandra-mini-btn"; btn.title = "Hablar con Sandra";
  btn.setAttribute("aria-label", "Abrir Sandra");
  btn.innerHTML = "S";
  document.body.appendChild(btn);

  const pop = document.createElement("div");
  pop.className = "sandra-mini-pop sandra-mini-hide";
  pop.innerHTML = `
    <div class="sandra-mini-row">
      <div class="sandra-mini-title">Sandra <span class="sandra-mini-chip">mini</span></div>
      <div class="sandra-mini-small" id="sandra-mini-status">idle</div>
    </div>
    ${cfg.pills ? (`<div class="sandra-mini-pills">
      <button class="sandra-mini-pill" id="sandra-pill-stt">🎙️ Dictado</button>
      <button class="sandra-mini-pill" id="sandra-pill-voice">🗣️ Voz</button>
      <button class="sandra-mini-pill" id="sandra-pill-avatar">🎬 Avatar</button>
    </div>`) : ""}
    <textarea class="sandra-mini-area" id="sandra-mini-input" placeholder="Escribe o usa Dictado…"></textarea>
    <div class="sandra-mini-actions">
      <button class="sandra-mini-ghost" id="sandra-mini-copy">Copiar</button>
      <button class="sandra-mini-solid" id="sandra-mini-send">Enviar</button>
    </div>
    <div class="sandra-mini-small">Backend: ${cfg.backend}</div>
  `;
  document.body.appendChild(pop);

  // ---- State ----
  let sttActive = false;
  let sttWS = null;
  let voicePC = null;
  let voiceStream = null;
  let avatarPC = null;
  let outAudio = null;

  function setStatus(text) {
    const el = document.getElementById("sandra-mini-status"); if (el) el.textContent = text;
  }

  // ---- Helpers ----
  const http = {
    async get(path) {
      const url = path.startsWith("http") ? path : cfg.backend.replace(/\/$/, "") + path;
      const r = await fetch(url, { credentials: "include" });
      if (!r.ok) throw new Error("HTTP " + r.status);
      return r.json();
    }
  };

  function wsURL(path) {
    if (path.startsWith("ws")) return path;
    const b = new URL(cfg.backend);
    const proto = b.protocol === "https:" ? "wss:" : "ws:";
    const host = b.host;
    const p = path.startsWith("/") ? path : ("/" + path);
    return `${proto}//${host}${p}`;
  }

  // ---- UI handlers ----
  btn.addEventListener("click", () => {
    pop.classList.toggle("sandra-mini-hide");
  });

  document.getElementById("sandra-mini-copy").addEventListener("click", () => {
    const ta = document.getElementById("sandra-mini-input");
    ta.select(); document.execCommand("copy");
    setStatus("copiado");
    setTimeout(() => setStatus("idle"), 1000);
  });

  document.getElementById("sandra-mini-send").addEventListener("click", async () => {
    const ta = document.getElementById("sandra-mini-input");
    const text = (ta.value || "").trim();
    if (!text) { setStatus("vacío"); setTimeout(() => setStatus("idle"), 800); return; }
    // Placeholder: send to your chat endpoint if desired
    setStatus("enviando…");
    try {
      // Example POST if you implement /api/chat
      await fetch(cfg.backend.replace(/\/$/, "") + "/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: text })
      });
      setStatus("enviado");
    } catch (e) {
      console.warn("[SandraMini] send error", e);
      setStatus("error");
    } finally {
      setTimeout(() => setStatus("idle"), 1000);
    }
  });

  // ---- 🎙️ Dictado (WS to /ws/stt) with graceful fallback ----
  async function startDictation() {
    if (sttActive) return;
    sttActive = true; setStatus("stt…");
    // Try native Web Speech API first (super lightweight).
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (SR) {
      const recog = new SR(); recog.lang = "es-ES"; recog.interimResults = true;
      recog.continuous = false;
      recog.onresult = (ev) => {
        const ta = document.getElementById("sandra-mini-input");
        const txt = Array.from(ev.results).map(r => r[0].transcript).join(" ");
        ta.value = txt;
      };
      recog.onend = () => { sttActive = false; setStatus("idle"); };
      recog.onerror = () => { sttActive = false; setStatus("error"); };
      recog.start();
      return;
    }
    // If you prefer your own WS STT, wire it here.
    try {
      sttWS = new WebSocket(wsURL("/ws/stt"));
      const media = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mr = new MediaRecorder(media, { mimeType: "audio/webm" });
      mr.ondataavailable = (e) => { if (e.data.size && sttWS && sttWS.readyState === 1) sttWS.send(e.data); };
      sttWS.onmessage = (e) => {
        try {
          const data = JSON.parse(e.data);
          if (data.text) document.getElementById("sandra-mini-input").value = data.text;
        } catch(_) {}
      };
      sttWS.onopen = () => mr.start(250);
      sttWS.onclose = () => { try { mr.stop(); } catch(_){} sttActive = false; setStatus("idle"); };
      sttWS.onerror = () => { try { mr.stop(); } catch(_){} sttActive = false; setStatus("error"); };
    } catch (e) {
      console.warn("[SandraMini] STT error", e);
      sttActive = false; setStatus("error");
    }
  }

  function stopDictation() {
    sttActive = false;
    if (sttWS && sttWS.readyState === 1) sttWS.close();
  }

  // ---- 🗣️ Voice (OpenAI Realtime via ephemeral token from your backend) ----
  async function startVoice() {
    setStatus("voz…");
    try {
      const tokenRes = await http.get(`/token/realtime?model=${encodeURIComponent(cfg.model)}`);
      const ephem = tokenRes.client_secret || tokenRes.token;
      if (!ephem) throw new Error("No ephemeral token from /token/realtime");
      // Prepare WebRTC
      voicePC = new RTCPeerConnection();
      // Audio out
      if (!outAudio) {
        outAudio = document.createElement("audio");
        outAudio.autoplay = true; outAudio.playsInline = true;
        document.body.appendChild(outAudio);
      }
      voicePC.ontrack = (ev) => { outAudio.srcObject = ev.streams[0]; };
      // Audio in
      voiceStream = await navigator.mediaDevices.getUserMedia({ audio: true });
      voiceStream.getTracks().forEach(t => voicePC.addTrack(t, voiceStream));
      // Data channel (optional)
      const dc = voicePC.createDataChannel("oai-events");
      dc.onmessage = (ev) => console.debug("[SandraMini] Realtime event", ev.data);

      const offer = await voicePC.createOffer({ offerToReceiveAudio: true, offerToReceiveVideo: false });
      await voicePC.setLocalDescription(offer);

      const sdpResponse = await fetch("https://api.openai.com/v1/realtime?model=" + encodeURIComponent(cfg.model), {
        method: "POST",
        headers: {
          Authorization: "Bearer " + ephem,
          "Content-Type": "application/sdp"
        },
        body: offer.sdp
      });
      if (!sdpResponse.ok) throw new Error("Realtime SDP failed " + sdpResponse.status);
      const answerSDP = await sdpResponse.text();
      await voicePC.setRemoteDescription({ type: "answer", sdp: answerSDP });
      setStatus("hablando");
    } catch (e) {
      console.warn("[SandraMini] Voice error", e);
      setStatus("error");
    }
  }

  async function stopVoice() {
    try {
      if (voicePC) { voicePC.close(); voicePC = null; }
      if (voiceStream) { voiceStream.getTracks().forEach(t => t.stop()); voiceStream = null; }
    } catch(_) {}
    setStatus("idle");
  }

  // ---- 🎬 Avatar (via your provider token/endpoint) ----
  async function startAvatar() {
    setStatus("avatar…");
    try {
      const { rtcEndpoint, token } = await http.get("/token/avatar");
      if (!rtcEndpoint || !token) throw new Error("Missing rtcEndpoint/token");
      avatarPC = new RTCPeerConnection();
      const vid = document.createElement("video");
      vid.autoplay = true; vid.playsInline = true; vid.style.width = "100%"; vid.style.borderRadius = "10px";
      pop.appendChild(vid);
      avatarPC.ontrack = (ev) => { vid.srcObject = ev.streams[0]; };
      const offer = await avatarPC.createOffer({ offerToReceiveVideo: true, offerToReceiveAudio: true });
      await avatarPC.setLocalDescription(offer);
      const r = await fetch(rtcEndpoint, {
        method: "POST",
        headers: { Authorization: "Bearer " + token, "Content-Type": "application/sdp" },
        body: offer.sdp
      });
      if (!r.ok) throw new Error("Avatar SDP failed " + r.status);
      const answer = await r.text();
      await avatarPC.setRemoteDescription({ type: "answer", sdp: answer });
      setStatus("avatar listo");
    } catch (e) {
      console.warn("[SandraMini] Avatar error", e);
      setStatus("error");
    }
  }
  async function stopAvatar() {
    try { if (avatarPC) { avatarPC.close(); avatarPC = null; } } catch(_) {}
    setStatus("idle");
  }

  // ---- Bind pills (if visible) ----
  if (cfg.pills) {
    const pSTT = document.getElementById("sandra-pill-stt");
    const pVoice = document.getElementById("sandra-pill-voice");
    const pAvatar = document.getElementById("sandra-pill-avatar");

    if (pSTT) pSTT.addEventListener("click", () => {
      if (!sttActive) startDictation(); else stopDictation();
    });
    if (pVoice) pVoice.addEventListener("click", () => {
      if (!voicePC) startVoice(); else stopVoice();
    });
    if (pAvatar) pAvatar.addEventListener("click", () => {
      if (!avatarPC) startAvatar(); else stopAvatar();
    });
  }

  // ---- Autoplay hint (must click first) ----
  window.addEventListener("click", () => {
    if (outAudio) { outAudio.muted = false; try { outAudio.play(); } catch(_){} }
  }, { once: true });
})();