# 📦 Sandra Widget · Mini (CONNECTED)

Widget súper ligero con **popover compacto** y **píldoras reales** para Dictado, Voz y Avatar, ya preparado para conectarse a tu backend.

## ✅ Incluye
- `sandra-mini-connected.js` → UI mínima, sin dependencias.
  - 🎙️ **Dictado** → WebSocket a `/ws/stt` (fallback Web Speech API).
  - 🗣️ **Voz** → token efímero desde `/token/realtime` (WebRTC a OpenAI).
  - 🎬 **Avatar** → `token/endpoint` desde `/token/avatar` (WebRTC al proveedor).
- `README.md` → esta guía rápida.

---

## ⚡ Integración (2 líneas)

```html
<script src="/sandra-mini-connected.js"
        defer
        data-backend="https://guestsvalencia.es"
        data-theme="auto"
        data-pills="on"
        data-model="gpt-4o-realtime-preview-2024-12-17"></script>
```

> Coloca `sandra-mini-connected.js` en la raíz pública de tu web o en tu CDN y ajusta `data-backend` a tu dominio.

---

## 🔌 Backend esperado

### 1) Realtime (voz)
`GET /token/realtime?model=...` → devuelve un **token efímero** (campo `client_secret` o `token`) válido para iniciar una sesión WebRTC con OpenAI Realtime.

**Respuesta ejemplo:**
```json
{ "client_secret": "ephemeral-xxxxx" }
```

### 2) Avatar
`GET /token/avatar` → devuelve:
```json
{ "rtcEndpoint": "https://provider.example.com/v1/rtc", "token": "provider-xxxxx" }
```

### 3) STT (dictado)
`wss://TU_DOMINIO/ws/stt` → acepta chunks `audio/webm` (MediaRecorder) y devuelve mensajes con transcripciones.
**Mensaje de ejemplo:**
```json
{ "text": "hola mundo" }
```

---

## 🔒 Requisitos
- **HTTPS** en tu dominio (Caddy/NGINX con TLS).
- **CORS** en el backend (ejemplo):
```
CORS_ORIGINS=https://guestsvalencia.es,https://www.guestsvalencia.es
```
- **Variables**:
```
OPENAI_API_KEY=...
# (Opcional avatar) claves y endpoints de HeyGen/GIGN/Cartesia.
```

---

## 🧩 Ejemplo Caddy (proxy + WS)
```caddyfile
example.com {
  encode gzip
  reverse_proxy /ws/* 127.0.0.1:8080 {
    header_up Host {host}
  }
  reverse_proxy / 127.0.0.1:3000
}
```

---

## 🛠️ Troubleshooting rápido
- **Micrófono bloqueado** → el navegador pedirá permiso; acepta y recarga.
- **WS cerrado** → revisa que `wss://tu_dominio/ws/stt` esté accesible (proxy WS activo).
- **No suena la voz** → haz un primer *click* (autoplay policy) y confirma que `/token/realtime` devuelve el token efímero.
- **Avatar no arranca** → el backend debe responder `{ ok:true, rtcEndpoint, token }` (o sin `ok`, pero con esos campos).

---

## 🧪 Notas
- El botón flotante **no tapa** tu web (56px); el popover es de **320px**.
- Tema **auto** (oscuro/claro según sistema). Puedes forzar `data-theme="light"` o `"dark"`.
- Si implementas `/api/chat`, el botón **Enviar** ya hace `POST` con `{ message }`.

---

Con ❤️ para GuestsValencia y Sandra IA.
